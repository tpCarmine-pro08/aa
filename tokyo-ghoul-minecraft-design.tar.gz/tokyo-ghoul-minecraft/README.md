# Tokyo Ghoul:re × Minecraft

A Minecraft Java RPG mashup in which a custom character chooses Ghoul or CCG and explores a large Tokyo-inspired urban district. The first playable slice focuses on faction identity, encounters, combat, objectives and progression.

The mashup must use real content from the player's own installation of **TOKYO GHOUL：re [CALL to EXIST]** at runtime. Its game-owned content is not redistributed with the mod.

## v0.1 target
- Minecraft Java host
- Ghoul and CCG choices
- Custom character
- Urban Tokyo-inspired district
- Day/night cycle
- Faction encounters
- Combat and progression
- Faction objectives
- Recognizable CALL to EXIST integration
- Single player

## Current status
Design complete. Build and Melty validation are still required.
