# Tokyo Ghoul:re × Minecraft — preflight

## Status
**DESIGN READY / BUILD BLOCKED**

No game build was produced because the actual installed Windows game directories and Melty creator API are not exposed to this execution environment. This is intentional: claiming a tested build without those inputs would be false.

## Clean cells
- Mashup concept: PASS
- Minecraft primary host: PASS
- Tokyo Ghoul real-content requirement: PASS
- Ghoul/CCG split: PASS
- First-minute loop: PASS
- Solo v1 scope: PASS
- No redistribution of game-owned content: PASS

## Blocking cells
1. Minecraft installed version — must inspect the local installation.
2. Melty-supported loader/version — must verify with Melty `game_info`.
3. Tokyo Ghoul:re [CALL to EXIST] install path — must inspect Steam libraries.
4. Actual Tokyo Ghoul asset/data access — must inspect the installed files.
5. Runtime loader/integration implementation — depends on #2–#4.
6. Playable Minecraft build — not created yet.
7. In-game test — not run.
8. Melty package inspection/recipe validation/one-click check — not run because creator tools are unavailable here.
9. Real gameplay screenshot — cannot be captured until the build runs.

## Rule
Do not publish or describe this project as playable until every blocking cell is verified and the release passes Melty's package, recipe and one-click checks.
